//
//  ApiAccess.swift
//  LeagueStats
//
//  Created by Cray on 12/9/18.
//

import Foundation
import LeagueAPI



class ApiAccess {
    
    var name:String
    init(name:String) {
        self.name = name
    }
    
}
var api = ApiAccess(name:"RGAPI-324a3d6e-364b-4928-bf7b-a86169f1a309")

