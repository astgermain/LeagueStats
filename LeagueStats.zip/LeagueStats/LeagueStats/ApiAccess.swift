//
//  ApiAccess.swift
//  LeagueStats
//
//  Created by Cray on 12/9/18.
//

import Foundation
import LeagueAPI



class ApiAccess {
    
    var name:String
    init(name:String) {
        self.name = name
    }
    
}
var api = ApiAccess(name:"RGAPI-06b7fe87-ffe6-45b1-a17c-b276ad7d1e59")

