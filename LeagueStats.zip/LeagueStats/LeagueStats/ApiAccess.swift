//
//  ApiAccess.swift
//  LeagueStats
//
//  Created by Cray on 12/9/18.
//

import Foundation
import LeagueAPI



class ApiAccess {
    
    var name:String
    init(name:String) {
        self.name = name
    }
    
}
var api = ApiAccess(name:"RGAPI-1cef176f-3412-4529-be24-9d77e3999c5e")

