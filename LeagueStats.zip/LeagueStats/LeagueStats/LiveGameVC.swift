//
//  LiveGameViewController.swift
//  LeagueStats
//
//  Created by Cray on 12/9/18.
//

import UIKit
import LeagueAPI
import DragonService
import Alamofire

class LiveGameVC: UIViewController {
    
        
    
    
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!
    @IBOutlet weak var name: UITextField!
    var summid: String = ""
    let baseUrl = "https://ddragon.leagueoflegends.com/cdn"
    let versionNum = "8.24.1"
    let localeVer = "en_US"
    lazy var imageViewArr = [imageView1, imageView2, imageView3]
    let resultVc: LiveGameResultsVC = LiveGameResultsVC()
    
    private func buildUrl(base: String, paths: [String]) -> URL? {
        var urlString = base
        for path in paths {
            urlString.append("/\(path)")
        }
        
        return URL(string: urlString)
    }
    
    func championImage(championName: String, imageViewNum: Int){
        
        DragonService.Champion().list(version: versionNum, locale: localeVer, completionHandler: { (champions) in
            //print(champions.data["Ahri"]!.name)
            //print(champions.data["Ahri"]!.lore)
            print(champions.data[championName]!.image)
            let campPaths = [self.versionNum, "img", "champion", champions.data[championName]!.image.full]
            let finalUrl = self.buildUrl(base: self.baseUrl, paths: campPaths)
            //for champion in champions{
            Alamofire.request(finalUrl!).responseData(completionHandler: { [weak self] (response) in
                guard let imageData = response.result.value else {
                    print("Image error")
                    return
                }
                let image = UIImage(data: imageData)
                let arrVal = imageViewNum - 1
                self?.imageViewArr[arrVal]!.image = image
                
            })
            //DragonService.Perks().list(version: versionNum, locale: "en_US", completionHandler: { (perks) in
            //var url = ""
            //print(perk.name)
            //print(perk.key)
            //print(perk.image)
            //print(perk.id)
            //}
        }, errorHandler: { (error) in
            if self.versionNum.isVersion(lessThan: "7.22.1") {
                print("XCTAssertNotNil(error)")
            } else {
                print(self.versionNum)
                print("XCTAssertNil(error)")
            }
            print("expectation.fulfill()")
        })
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        championImage(championName: "Ahri", imageViewNum: 1)
        championImage(championName: "Pyke", imageViewNum: 2)
        championImage(championName: "Brand", imageViewNum: 3)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    let league = LeagueAPI(APIToken: api.name)
    
 
    
    
    func getSummonerInfo(_ name: String) {
        
        league.riotAPI.getSummoner(byName: name, on: .NA) { (summoner, errorMsg) in
            if let summoner = summoner {
                
                print("summonerinfosuccess")
                //self.summid = "\(summoner.id)"
                
            }
            else {
                print("Request failed cause: \(errorMsg ?? "No error description")")
            }
        }
        
    }
    //I hate completion handlers
    
    func retrieveSummonerId(_ name: String, completionHandler: @escaping (String?) -> ()) {
        league.riotAPI.getSummoner(byName: name, on: .NA) { (summoner, errorMsg) in
            if let summoner = summoner {
                
                //print(summoner.id.value)
                //print("sumidendshere")
                let summid = summoner.id.value
                completionHandler(summid)
                
            }
            else {
                print("Request failed cause: \(errorMsg ?? "No error description")")
            }
            
        }
        
    }
    
    
    
    
   
    
    
    
    
    
    func getRankedPositions(_ id: String) {
        retrieveSummonerId(id) { summid in
        //guard let queue = Queue(.RankedSolo5V5) else { return }
            self.league.riotAPI.getRankedPositions(for: SummonerId(summid!), on: .NA) { (rankedPosition, errorMsg) in
            if let rankedPosition = rankedPosition {
                print(rankedPosition[0].tier)
                print(rankedPosition[0].leagueInfo.rank)
                print(rankedPosition[0].leagueInfo.leaguePoints)
                //print(rankedPosition[0].tier)
                print("rankedendshere")
            }
            else {
                print("Request failed cause: \(errorMsg ?? "No error description")")
            }
        }
        }
    }
    
    func getLiveGame(_ id: String) {
        retrieveSummonerId(id) { summid in
            self.league.riotAPI.getLiveGame(by: SummonerId(summid!), on: .NA) { (liveGame, errorMsg) in
            if let liveGame = liveGame {
                /*
                print(liveGame.participants[0].summonerName)
                print(liveGame.participants[0].summonerSpell1)
                /*for element in (liveGame.participants[0].runePage?.runeIds)!{
                    print(element)
                }
                 */
                //To get the primary mastery
                //resultVc.banned1 = championImage(championName: <#T##String#>, imageViewNum: <#T##Int#>)
                print(liveGame.participants[0].runePage?.runeIds[0])
                //To get primary tree
                print(liveGame.participants[0].runePage?.primaryPath)
                //To get secondary tree
                print(liveGame.participants[0].runePage?.secondaryPath)
                
                print("livegameendshere")
                */
                
            }
            else {
                print("Request failed cause: \(errorMsg ?? "No error description")")
            }
        }
        }
    }
    
    
    
    @IBAction func findGame(_ sender: Any) {
        //getSummonerInfo(name.text!)
        
        //getRankedPositions(name.text!)
        
        //getLiveGame(name.text!)
        //let summoner: Summoner = Summoner()
        
        
        performSegue(withIdentifier: "toResults", sender: self)
        resultVc.summonerName = name.text!
        //print(summonerInfo.getRankedPositions.tier)
    }
    /*
    @IBAction func submit(_ sender: UITextField) {
        //let (firstElement, _, _, _, _) = summonerInfo
        
        
    }
    */
    
    
    
    
    /*
    lazy var summonerName: String = SummonerName.text!
    
    
    lazy var summonerObject = getSummonerInfo(summonerName)
    
    
    lazy var summoner = Summoner(from: summonerObject as! Decoder)
    
    */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
