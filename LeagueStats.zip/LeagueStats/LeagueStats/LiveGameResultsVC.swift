//
//  LiveGameResultsVC.swift
//  LeagueStats
//
//  Created by I Am The Machine on 12/12/18.
//

import UIKit
import LeagueAPI
import DragonService
import Alamofire

class LiveGameResultsVC: UIViewController {

    let league = LeagueAPI(APIToken: api.name)
    var summonerName: String = "aphromoo"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        print(summonerName)
        getLiveGame(summonerName)
        print("secondViewDidLoad")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var banned1: UIImageView!
    @IBOutlet weak var banned2: UIImageView!
    @IBOutlet weak var banned3: UIImageView!
    @IBOutlet weak var banned4: UIImageView!
    @IBOutlet weak var banned5: UIImageView!
    @IBOutlet weak var banned6: UIImageView!
    @IBOutlet weak var banned7: UIImageView!
    @IBOutlet weak var banned8: UIImageView!
    @IBOutlet weak var banned9: UIImageView!
    @IBOutlet weak var banned10: UIImageView!
    
    
    
    var summid2: String = ""
    let baseUrl = "https://ddragon.leagueoflegends.com/cdn"
    let versionNum = "8.24.1"
    let localeVer = "en_US"
    lazy var bannedArr = [banned1, banned2, banned3, banned4, banned5, banned6, banned7, banned8, banned9, banned10]
    
    
    
    private func buildUrl(base: String, paths: [String]) -> URL? {
        var urlString = base
        for path in paths {
            urlString.append("/\(path)")
        }
        
        return URL(string: urlString)
    }
    
    func championImage(championName: String, imageViewNum: Int){
        
        DragonService.Champion().list(version: versionNum, locale: localeVer, completionHandler: { (champions) in
            //print(champions.data["Ahri"]!.name)
            //print(champions.data["Ahri"]!.lore)
            print(champions.data[championName]!.image)
            let campPaths = [self.versionNum, "img", "champion", champions.data[championName]!.image.full]
            let finalUrl = self.buildUrl(base: self.baseUrl, paths: campPaths)
            //for champion in champions{
            Alamofire.request(finalUrl!).responseData(completionHandler: { [weak self] (response) in
                guard let imageData = response.result.value else {
                    print("Image error")
                    return
                }
                let image = UIImage(data: imageData)
                let arrVal = imageViewNum - 1
                self?.bannedArr[arrVal]!.image = image
                
            })
            //DragonService.Perks().list(version: versionNum, locale: "en_US", completionHandler: { (perks) in
            //var url = ""
            //print(perk.name)
            //print(perk.key)
            //print(perk.image)
            //print(perk.id)
            //}
        }, errorHandler: { (error) in
            if self.versionNum.isVersion(lessThan: "7.22.1") {
                print("XCTAssertNotNil(error)")
            } else {
                print(self.versionNum)
                print("XCTAssertNil(error)")
            }
            print("expectation.fulfill()")
        })
        
    }
    
    
    
    
    func retrieveSummonerId(_ name: String, completionHandler: @escaping (String?) -> ()) {
        league.riotAPI.getSummoner(byName: name, on: .NA) { (summoner, errorMsg) in
            if let summoner = summoner {
                
                //print(summoner.id.value)
                //print("sumidendshere")
                let summid2 = summoner.id.value
                completionHandler(summid2)
                
            }
            else {
                print("here")
                print("Request failed cause: \(errorMsg ?? "No error description")")
            }
            
        }
        
    }
    
    
    
    func getLiveGame(_ id: String) {
        retrieveSummonerId(id) { summid2 in
            self.league.riotAPI.getLiveGame(by: SummonerId(summid2!), on: .NA) { (liveGame, errorMsg) in
                if let liveGame = liveGame {
                    let parts = liveGame.participants
                    var counter: Int = 1
                    
                        for part in parts {
                            self.league.getChampionDetails(by: part.championId) { (championDeets, errorMsg) in
                                if let championDeets = championDeets {
                                    let s = championDeets.name
                                    let sone = s.replacingOccurrences(of: " ", with: "")
                                    let stwo = sone.replacingOccurrences(of: "Wukong", with: "MonkeyKing")
                                    let sfinal = stwo.replacingOccurrences(of: "'", with: "")
                                    if counter < 11 {
                                        self.championImage(championName: sfinal, imageViewNum: counter)
                                        print(championDeets.name)
                                    }
                                }
                                else {
                                    print("Request failed cause: \(errorMsg ?? "No error description")")
                                }
                            }
                            counter = counter + 1
                        }
                    
                    print("ItWorkd")
                    //print(liveGame.participants[0].summonerName)
                    //print(liveGame.participants[0].summonerSpell1)
                    /*for element in (liveGame.participants[0].runePage?.runeIds)!{
                     print(element)
                     }
                     */
                    //To get the primary mastery
                    //resultVc.banned1 = championImage(championName: <#T##String#>, imageViewNum: <#T##Int#>)
                    //print(liveGame.participants[0].runePage?.runeIds[0])
                    //To get primary tree
                    //print(liveGame.participants[0].runePage?.primaryPath)
                    //To get secondary tree
                    //print(liveGame.participants[0].runePage?.secondaryPath)
                    
                    print("livegameendshere")
                }
                else {
                    print("Request failed cause: \(errorMsg ?? "No error description")")
                }
            }
        }
    }
    
}
